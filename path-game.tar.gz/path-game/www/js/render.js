'use strict';
/* =========================================================
 * 路径谜题 · Canvas 渲染模块
 * ========================================================= */

const Render = (function () {
  const PAD = 14;

  const C = {
    bg: '#eef1f5',
    checkerA: '#ffffff',
    checkerB: '#f3f6fa',
    grid: '#c3ccd6',
    border: '#546e7a',
    obstacle: '#45525e',
    obstacleX: '#93a4b2',
    startFill: '#1e88e5',
    endFill: '#8e24aa',
    label: '#ffffff',
    hubStroke: '#f9a825',
    hubFill: 'rgba(249,168,37,0.16)',
    diag: '#00897b',
    redEdge: '#e53935',
    greenEdge: '#2e7d32',
    pathMain: '#1a73e8',
    pathCase: 'rgba(255,255,255,0.92)',
    err: '#e53935',
    sel: '#3949ab',
    hover: '#64b5f6',
    num: '#0d47a1'
  };

  function cellSize(level, w, h) {
    const cw = (w - PAD * 2) / level.cols;
    const ch = (h - PAD * 2) / level.rows;
    return Math.max(8, Math.floor(Math.min(cw, ch)));
  }

  function metrics(level, w, h) {
    const cs = cellSize(level, w, h);
    return {
      cs,
      ox: (w - cs * level.cols) / 2,
      oy: (h - cs * level.rows) / 2
    };
  }

  function center(m, r, c) {
    return [m.ox + c * m.cs + m.cs / 2, m.oy + r * m.cs + m.cs / 2];
  }

  function rr(ctx, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  /* ---------- 主绘制入口 ----------
   * opts: { path, showNumbers, highlights:{hover, sel, errors:[keys], warn:[keys]},
   *         preview:{color, from, to} }
   */
  function draw(canvas, level, opts) {
    opts = opts || {};
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const W = rect.width, H = rect.height;
    const pw = Math.round(W * dpr), ph = Math.round(H * dpr);
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    ctx.fillStyle = C.bg;
    ctx.fillRect(0, 0, W, H);

    const m = metrics(level, W, H);
    const cs = m.cs;
    if (cs < 6) return;

    drawChecker(ctx, m, level);
    drawFeatures(ctx, m, level);
    drawEdges(ctx, m, level);
    drawGrid(ctx, m, level);
    if (opts.path && opts.path.length) drawPath(ctx, m, level, opts);
    drawHighlights(ctx, m, level, opts.highlights || {});
    if (opts.preview && opts.preview.from && opts.preview.to) drawPreview(ctx, m, level, opts.preview);
    drawBorder(ctx, m, level);
  }

  /* 棋盘底色 */
  function drawChecker(ctx, m, level) {
    for (let r = 0; r < level.rows; r++) {
      for (let c = 0; c < level.cols; c++) {
        const x = m.ox + c * m.cs, y = m.oy + r * m.cs;
        ctx.fillStyle = ((r + c) % 2 === 0) ? C.checkerA : C.checkerB;
        ctx.fillRect(x, y, m.cs, m.cs);
      }
    }
  }

  /* 格子特征：障碍 / 枢纽 / 斜向 / 起终点 */
  function drawFeatures(ctx, m, level) {
    const cs = m.cs;
    for (let r = 0; r < level.rows; r++) {
      for (let c = 0; c < level.cols; c++) {
        const x = m.ox + c * cs, y = m.oy + r * cs;
        const cx = x + cs / 2, cy = y + cs / 2;
        if (level.isObstacle(r, c)) {
          ctx.fillStyle = C.obstacle;
          rr(ctx, x + 1, y + 1, cs - 2, cs - 2, cs * 0.12);
          ctx.fill();
          ctx.strokeStyle = C.obstacleX;
          ctx.lineWidth = Math.max(1.5, cs * 0.08);
          const d = cs * 0.22;
          ctx.beginPath();
          ctx.moveTo(cx - d, cy - d); ctx.lineTo(cx + d, cy + d);
          ctx.moveTo(cx - d, cy + d); ctx.lineTo(cx + d, cy - d);
          ctx.stroke();
          continue;
        }
        const isHub = level.isHub(r, c);
        const isDiag = level.isDiagonal(r, c);
        if (isDiag) {
          ctx.strokeStyle = C.diag;
          ctx.lineWidth = Math.max(1.5, cs * 0.09);
          const d = cs * 0.3;
          ctx.beginPath();
          ctx.moveTo(cx - d, cy - d); ctx.lineTo(cx + d, cy + d);
          ctx.moveTo(cx - d, cy + d); ctx.lineTo(cx + d, cy - d);
          ctx.stroke();
        }
        if (isHub) {
          ctx.fillStyle = C.hubFill;
          rr(ctx, x + 1.5, y + 1.5, cs - 3, cs - 3, cs * 0.14);
          ctx.fill();
          ctx.strokeStyle = C.hubStroke;
          ctx.lineWidth = Math.max(2, cs * 0.1);
          ctx.beginPath();
          ctx.arc(cx, cy, cs * 0.28, 0, Math.PI * 2);
          ctx.stroke();
          ctx.fillStyle = C.hubStroke;
          ctx.beginPath();
          ctx.arc(cx, cy, Math.max(1.5, cs * 0.05), 0, Math.PI * 2);
          ctx.fill();
        }
        if (level.isStart(r, c)) {
          drawSE(ctx, cx, cy, cs, C.startFill, 'S');
        } else if (level.isEnd(r, c)) {
          drawSE(ctx, cx, cy, cs, C.endFill, 'E');
        }
      }
    }
  }

  function drawSE(ctx, cx, cy, cs, color, ch) {
    const r = cs * 0.32;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();
    ctx.lineWidth = Math.max(1.5, cs * 0.05);
    ctx.strokeStyle = 'rgba(0,0,0,0.25)';
    ctx.stroke();
    const fs = Math.max(9, cs * 0.42);
    ctx.fillStyle = C.label;
    ctx.font = 'bold ' + fs + 'px "Segoe UI", system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(ch, cx, cy + fs * 0.04);
  }

  /* 红/绿边 */
  function drawEdges(ctx, m, level) {
    const w = Math.max(3, Math.round(m.cs * 0.16));
    drawEdgeSet(ctx, m, level.redEdges, C.redEdge, w);
    drawEdgeSet(ctx, m, level.greenEdges, C.greenEdge, w);
  }

  function drawEdgeSet(ctx, m, set, color, w) {
    ctx.strokeStyle = color;
    ctx.lineWidth = w;
    ctx.lineCap = 'butt';
    for (const k of set) {
      const [a, b] = k.split('|').map(p => p.split(',').map(Number));
      if (Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) === 1) {
        /* 正交：画在共享边上 */
        if (a[0] === b[0]) {
          const r = a[0], c = Math.max(a[1], b[1]);
          const x = m.ox + c * m.cs, y1 = m.oy + r * m.cs, y2 = y1 + m.cs;
          ctx.beginPath();
          ctx.moveTo(x, y1); ctx.lineTo(x, y2);
          ctx.stroke();
        } else {
          const c = a[1], r = Math.max(a[0], b[0]);
          const y = m.oy + r * m.cs, x1 = m.ox + c * m.cs, x2 = x1 + m.cs;
          ctx.beginPath();
          ctx.moveTo(x1, y); ctx.lineTo(x2, y);
          ctx.stroke();
        }
      } else {
        /* 斜向：画在共享角点交叉的短线上 */
        const dr = b[0] - a[0], dc = b[1] - a[1];
        const cornerX = m.ox + (Math.max(a[1], b[1])) * m.cs;
        const cornerY = m.oy + (Math.max(a[0], b[0])) * m.cs;
        const d = m.cs * 0.24;
        /* 方向向量 (dr, dc) 归一化 */
        const dx = dr / (Math.abs(dr) || 1), dy = dc / (Math.abs(dc) || 1);
        ctx.beginPath();
        ctx.moveTo(cornerX - dx * d, cornerY - dy * d);
        ctx.lineTo(cornerX + dx * d, cornerY + dy * d);
        ctx.stroke();
      }
    }
  }

  /* 网格线 */
  function drawGrid(ctx, m, level) {
    ctx.strokeStyle = C.grid;
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let c = 1; c < level.cols; c++) {
      const x = m.ox + c * m.cs;
      ctx.moveTo(x, m.oy); ctx.lineTo(x, m.oy + level.rows * m.cs);
    }
    for (let r = 1; r < level.rows; r++) {
      const y = m.oy + r * m.cs;
      ctx.moveTo(m.ox, y); ctx.lineTo(m.ox + level.cols * m.cs, y);
    }
    ctx.stroke();
  }

  function drawBorder(ctx, m, level) {
    ctx.strokeStyle = C.border;
    ctx.lineWidth = 2;
    ctx.strokeRect(m.ox, m.oy, level.cols * m.cs, level.rows * m.cs);
  }

  /* 玩家路径 */
  function drawPath(ctx, m, level, opts) {
    const cs = m.cs;
    const pts = opts.path.map(p => center(m, p[0], p[1]));
    const mainW = Math.max(3, cs * 0.26);
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    if (pts.length >= 1) {
      ctx.strokeStyle = C.pathCase;
      ctx.lineWidth = mainW + 5;
      tracePath(ctx, pts);
      ctx.stroke();
      ctx.strokeStyle = C.pathMain;
      ctx.lineWidth = mainW;
      tracePath(ctx, pts);
      ctx.stroke();
    }
    /* 起点小圆点（覆盖路径起始） */
    const [sx, sy] = center(m, opts.path[0][0], opts.path[0][1]);
    ctx.beginPath();
    ctx.arc(sx, sy, mainW / 2 + 1, 0, Math.PI * 2);
    ctx.fillStyle = C.startFill;
    ctx.fill();
    /* 序号 */
    if (opts.showNumbers && cs >= 26) {
      ctx.font = 'bold ' + Math.max(8, cs * 0.3) + 'px "Segoe UI", system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      for (let i = 0; i < opts.path.length; i++) {
        const p = opts.path[i];
        if (level.isObstacle(p[0], p[1])) continue;
        if (level.isStart(p[0], p[1]) || level.isEnd(p[0], p[1])) continue;
        const [x, y] = center(m, p[0], p[1]);
        const txt = String(i + 1);
        ctx.strokeStyle = 'rgba(255,255,255,0.9)';
        ctx.lineWidth = 3;
        ctx.strokeText(txt, x, y);
        ctx.fillStyle = C.num;
        ctx.fillText(txt, x, y);
      }
    }
  }

  function tracePath(ctx, pts) {
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
  }

  /* 高亮：hover / 已选 / 错误 / 警告 */
  function drawHighlights(ctx, m, level, h) {
    const cs = m.cs;
    const stroke = (p, color, w, dash) => {
      const x = m.ox + p[1] * cs, y = m.oy + p[0] * cs;
      ctx.strokeStyle = color;
      ctx.lineWidth = w;
      ctx.setLineDash(dash || []);
      rr(ctx, x + 1.5, y + 1.5, cs - 3, cs - 3, cs * 0.15);
      ctx.stroke();
      ctx.setLineDash([]);
    };
    if (h.errors) {
      const seen = new Set();
      for (const k of h.errors) {
        if (seen.has(k)) continue;
        seen.add(k);
        const [r, c] = k.split(',').map(Number);
        stroke([r, c], C.err, Math.max(2.5, cs * 0.12));
      }
    }
    if (h.sel) stroke(h.sel, C.sel, Math.max(2.5, cs * 0.12), [4, 3]);
    if (h.hover) stroke(h.hover, C.hover, Math.max(2, cs * 0.09));
  }

  /* 边工具预览线 */
  function drawPreview(ctx, m, level, pv) {
    const color = pv.color === 'red' ? C.redEdge : C.greenEdge;
    const [x1, y1] = center(m, pv.from[0], pv.from[1]);
    const [x2, y2] = center(m, pv.to[0], pv.to[1]);
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(2, m.cs * 0.08);
    ctx.setLineDash([5, 4]);
    ctx.beginPath();
    ctx.moveTo(x1, y1); ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  /* 事件坐标 → 格子 */
  function cellAt(canvas, level, clientX, clientY) {
    const rect = canvas.getBoundingClientRect();
    const m = metrics(level, rect.width, rect.height);
    const c = Math.floor((clientX - rect.left - m.ox) / m.cs);
    const r = Math.floor((clientY - rect.top - m.oy) / m.cs);
    return (r >= 0 && r < level.rows && c >= 0 && c < level.cols) ? [r, c] : null;
  }

  return { draw, cellAt, metrics, center, PAD, C };
})();

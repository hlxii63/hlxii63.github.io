'use strict';
/* =========================================================
 * 路径谜题 · 应用引导：模式切换 / Toast / 弹窗 / 状态栏
 * ========================================================= */

const App = (function () {
  let mode = 'editor';

  function $(id) { return document.getElementById(id); }

  function init() {
    if (window.__appInited) return;
    window.__appInited = true;
    $('tab-editor').addEventListener('click', () => switchMode('editor'));
    $('tab-player').addEventListener('click', () => switchMode('player'));

    document.querySelectorAll('.modal').forEach(m => {
      m.addEventListener('click', e => { if (e.target === m) closeModal(m.id); });
    });

    document.addEventListener('keydown', e => {
      if (mode !== 'editor') return;
      const t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT')) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) Editor.redo(); else Editor.undo();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        Editor.redo();
      }
    });

    window.addEventListener('resize', () => { Editor.render(); Player.render(); });
    window.addEventListener('orientationchange', () => {
      setTimeout(() => { Editor.render(); Player.render(); }, 150);
    });

    Editor.init();
    Player.init();
    Editor.render();
    setStatus('💡 在编辑器中用工具设计关卡，然后点击「▶ 试玩当前关卡」');
  }

  function switchMode(m) {
    if (m === mode) { renderActive(); return; }
    if (m === 'player') {
      const lv = Editor.getLevel();
      if (!lv.start || !lv.end) {
        toast('请先在编辑器中放置起点 S 和终点 E');
        return;
      }
      Player.loadLevel(JSON.parse(JSON.stringify(lv.toJSON())));
    }
    mode = m;
    $('editor-panel').classList.toggle('hidden', m !== 'editor');
    $('player-panel').classList.toggle('hidden', m !== 'player');
    $('tab-editor').classList.toggle('active', m === 'editor');
    $('tab-player').classList.toggle('active', m === 'player');
    renderActive();
  }

  function playCurrentLevel() {
    const lv = Editor.getLevel();
    if (!lv.start || !lv.end) {
      toast('请先放置起点 S 和终点 E');
      return;
    }
    switchMode('player');
  }

  function renderActive() {
    setTimeout(() => {
      if (mode === 'editor') Editor.render(); else Player.render();
    }, 30);
  }

  function toast(msg) {
    const el = $('toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove('show'), 2400);
  }

  function setStatus(html) {
    $('status').innerHTML = html;
  }

  function openModal(id) { $(id).classList.add('show'); }
  function closeModal(id) { $(id).classList.remove('show'); }

  function getMode() { return mode; }

  return { init, switchMode, playCurrentLevel, toast, setStatus, openModal, closeModal, getMode };
})();

document.addEventListener('DOMContentLoaded', App.init);

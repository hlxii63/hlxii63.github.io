'use strict';
/* =========================================================
 * 路径谜题 · 关卡编辑器
 * ========================================================= */

const Editor = (function () {
  let canvas = null;
  let level = new Level(6, 6, '新关卡');
  let tool = 'start';
  let edgeFrom = null;
  let hover = null;

  /* 历史记录：快照（JSON 字符串） */
  let history = [];
  let idx = -1;

  const TOOL_HINT = {
    start: '点击格子放置起点 S（只能有一个）',
    end: '点击格子放置终点 E（只能有一个）',
    obstacle: '点击格子放置/移除障碍',
    hub: '点击格子放置/移除枢纽（可多次经过）',
    diagonal: '点击格子放置/移除斜向连线格（可斜向进出）',
    erase: '擦除格子上的一切标记',
    redEdge: '先点一格，再点相邻格（含斜向）放置红边（禁止通过）',
    greenEdge: '先点一格，再点相邻格（含斜向）放置绿边（必须通过）'
  };

  function $(id) { return document.getElementById(id); }

  function init() {
    canvas = $('game');
    canvas.addEventListener('pointerdown', onPointerDown);
    canvas.addEventListener('pointermove', onPointerMove);
    canvas.addEventListener('pointerleave', onPointerLeave);

    document.querySelectorAll('#editor-panel .tool').forEach(btn => {
      btn.addEventListener('click', () => setTool(btn.dataset.tool));
    });
    $('btn-undo').addEventListener('click', undo);
    $('btn-redo').addEventListener('click', redo);
    $('btn-clear').addEventListener('click', clearLevel);
    $('btn-new').addEventListener('click', newLevel);
    $('btn-export').addEventListener('click', exportLevel);
    $('btn-import').addEventListener('click', () => App.openModal('modal-import'));
    $('btn-play').addEventListener('click', play);
    $('btn-help').addEventListener('click', () => App.openModal('modal-help'));

    $('import-file').addEventListener('change', onImportFile);
    $('import-apply').addEventListener('click', onImportText);
    $('export-close').addEventListener('click', () => App.closeModal('modal-export'));
    $('export-copy').addEventListener('click', onExportCopy);
    $('export-download').addEventListener('click', onExportDownload);
    $('import-close').addEventListener('click', () => App.closeModal('modal-import'));
    $('help-close').addEventListener('click', () => App.closeModal('modal-help'));

    const sel = $('in-sample');
    SAMPLE_LEVELS.forEach(s => {
      const o = document.createElement('option');
      o.value = s.id;
      o.textContent = s.name;
      sel.appendChild(o);
    });
    sel.addEventListener('change', () => {
      if (sel.value) loadSample(sel.value);
      sel.value = '';
    });

    snapshot();
    setTool('start');
  }

  /* ---------- 工具 ---------- */
  function setTool(t) {
    tool = t;
    edgeFrom = null;
    document.querySelectorAll('#editor-panel .tool').forEach(b => {
      b.classList.toggle('active', b.dataset.tool === t);
    });
    setStatus('<b>当前工具：</b>' + TOOL_HINT[t] + ' ｜ ' + statsText());
    render();
  }

  /* ---------- 历史 ---------- */
  function snapshot() {
    history = history.slice(0, idx + 1);
    history.push(JSON.stringify(level.toJSON()));
    if (history.length > 150) history.shift();
    idx = history.length - 1;
  }

  function applySnapshot(str) {
    const r = Level.fromJSON(JSON.parse(str));
    if (r.level) level = r.level;
    edgeFrom = null;
    render();
    refreshNameInput();
  }

  function undo() {
    if (idx > 0) { idx--; applySnapshot(history[idx]); }
    else App.toast('没有可撤销的操作');
  }

  function redo() {
    if (idx < history.length - 1) { idx++; applySnapshot(history[idx]); }
    else App.toast('没有可重做的操作');
  }

  /* ---------- 格子操作 ---------- */
  function onPointerDown(e) {
    if (App.getMode() !== 'editor') return;
    e.preventDefault();
    const cell = Render.cellAt(canvas, level, e.clientX, e.clientY);
    if (!cell) return;
    applyTool(cell);
  }

  function onPointerMove(e) {
    if (App.getMode() !== 'editor') return;
    const cell = Render.cellAt(canvas, level, e.clientX, e.clientY);
    if (cell !== hover) {
      hover = cell;
      render();
    }
  }

  function onPointerLeave() {
    hover = null;
    render();
  }

  function applyTool(cell) {
    const [r, c] = cell;
    switch (tool) {
      case 'start': {
        if (level.isObstacle(r, c)) { App.toast('该格是障碍，请先擦除'); return; }
        if (level.isEnd(r, c)) { App.toast('该格是终点'); return; }
        level.start = [r, c];
        level.hubs.delete(KEY(r, c));
        level.diagonals.delete(KEY(r, c));
        snapshot();
        break;
      }
      case 'end': {
        if (level.isObstacle(r, c)) { App.toast('该格是障碍，请先擦除'); return; }
        if (level.isStart(r, c)) { App.toast('该格是起点'); return; }
        level.end = [r, c];
        level.hubs.delete(KEY(r, c));
        level.diagonals.delete(KEY(r, c));
        snapshot();
        break;
      }
      case 'obstacle': {
        if (level.isStart(r, c) || level.isEnd(r, c)) { App.toast('该格是起点/终点，请先用擦除工具移除'); return; }
        const k = KEY(r, c);
        if (level.obstacles.has(k)) level.obstacles.delete(k);
        else { level.obstacles.add(k); level.hubs.delete(k); level.diagonals.delete(k); }
        snapshot();
        break;
      }
      case 'hub': {
        if (level.isStart(r, c) || level.isEnd(r, c)) { App.toast('该格是起点/终点，请先用擦除工具移除'); return; }
        if (level.isObstacle(r, c)) { App.toast('该格是障碍，请先擦除'); return; }
        const k = KEY(r, c);
        if (level.hubs.has(k)) level.hubs.delete(k); else level.hubs.add(k);
        snapshot();
        break;
      }
      case 'diagonal': {
        if (level.isStart(r, c) || level.isEnd(r, c)) { App.toast('该格是起点/终点，请先用擦除工具移除'); return; }
        if (level.isObstacle(r, c)) { App.toast('该格是障碍，请先擦除'); return; }
        const k = KEY(r, c);
        if (level.diagonals.has(k)) level.diagonals.delete(k); else level.diagonals.add(k);
        snapshot();
        break;
      }
      case 'erase': {
        const k = KEY(r, c);
        level.obstacles.delete(k);
        level.hubs.delete(k);
        level.diagonals.delete(k);
        if (level.isStart(r, c)) level.start = null;
        if (level.isEnd(r, c)) level.end = null;
        snapshot();
        break;
      }
      case 'redEdge':
      case 'greenEdge': {
        if (!edgeFrom) {
          edgeFrom = [r, c];
          App.toast('已选择 (' + r + ',' + c + ')，请点击相邻格（含斜向）');
        } else if (edgeFrom[0] === r && edgeFrom[1] === c) {
          edgeFrom = null;
        } else {
          if (!level.isAdjacent(edgeFrom, cell)) {
            App.toast('只能连接相邻的格子（上下左右或斜向）');
            return;
          }
          const color = tool === 'redEdge' ? 'red' : 'green';
          const exists = level.hasEdge(color, edgeFrom, cell);
          if (!exists && (level.isObstacle(edgeFrom[0], edgeFrom[1]) || level.isObstacle(r, c))) {
            App.toast('障碍格不能连接边');
            return;
          }
          level.toggleEdge(color, edgeFrom, cell);
          edgeFrom = null;
          snapshot();
        }
        break;
      }
    }
    setStatus('<b>当前工具：</b>' + TOOL_HINT[tool] + ' ｜ ' + statsText());
    render();
  }

  /* ---------- 关卡级操作 ---------- */
  function clearLevel() {
    level = new Level(level.rows, level.cols, nameValue());
    snapshot();
    render();
    App.toast('已清空，可重新设计');
  }

  function newLevel() {
    const rows = clampInt($('in-rows').value, 2, 30, 6);
    const cols = clampInt($('in-cols').value, 2, 30, 6);
    level = new Level(rows, cols, nameValue());
    snapshot();
    render();
    App.toast('已新建 ' + rows + '×' + cols + ' 空白关卡');
  }

  function loadSample(id) {
    const s = SAMPLE_LEVELS.find(x => x.id === id);
    if (!s) return;
    const r = Level.fromJSON(s);
    if (r.level) {
      level = r.level;
      level.name = s.name;
      snapshot();
      render();
      refreshNameInput();
      App.toast('已载入示例：「' + s.name + '」');
    }
  }

  function nameValue() {
    const v = $('in-name').value.trim();
    return v ? v : '未命名关卡';
  }

  function refreshNameInput() {
    $('in-name').value = level.name === '未命名关卡' ? '' : level.name;
  }

  /* ---------- 导出 ---------- */
  function exportLevel() {
    level.name = nameValue();
    const json = JSON.stringify(level.toJSON(), null, 2);
    $('export-text').value = json;
    App.openModal('modal-export');
    $('export-text').select();
  }

  function onExportCopy() {
    const ta = $('export-text');
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    if (!ok && navigator.clipboard) {
      navigator.clipboard.writeText(ta.value).then(
        () => App.toast('已复制到剪贴板'),
        () => App.toast('复制失败，请手动复制')
      );
      return;
    }
    App.toast(ok ? '已复制到剪贴板' : '复制失败，请手动复制');
  }

  function onExportDownload() {
    const json = $('export-text').value;
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = (level.name || 'level') + '.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  /* ---------- 导入 ---------- */
  function onImportFile(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      $('import-text').value = String(reader.result);
      applyImportText();
      e.target.value = '';
    };
    reader.readAsText(file);
  }

  function onImportText() {
    applyImportText();
  }

  function applyImportText() {
    let obj;
    try {
      obj = JSON.parse($('import-text').value);
    } catch (err) {
      App.toast('JSON 解析失败：' + err.message);
      return;
    }
    const r = Level.fromJSON(obj);
    if (!r.level || r.errors.length) {
      App.toast('导入失败：' + (r.errors.slice(0, 3).join('；') || '数据无效'));
      return;
    }
    level = r.level;
    snapshot();
    render();
    refreshNameInput();
    App.toast('导入成功' + (r.warnings.length ? '（注意：' + r.warnings[0] + '）' : ''));
    App.closeModal('modal-import');
    $('import-text').value = '';
  }

  /* ---------- 试玩 ---------- */
  function play() {
    level.name = nameValue();
    if (!level.start || !level.end) {
      App.toast('请先放置起点 S 和终点 E');
      return;
    }
    App.playCurrentLevel();
  }

  /* ---------- 渲染 ---------- */
  function render() {
    if (!canvas) return;
    const h = { hover };
    if (edgeFrom) h.sel = edgeFrom;
    const opts = { highlights: h };
    if ((tool === 'redEdge' || tool === 'greenEdge') && edgeFrom && hover &&
        level.isAdjacent(edgeFrom, hover)) {
      opts.preview = { color: tool === 'redEdge' ? 'red' : 'green', from: edgeFrom, to: hover };
    }
    Render.draw(canvas, level, opts);
  }

  function statsText() {
    const s = level.stats();
    return (s.hasStart ? 'S:' + level.start : '无起点') +
      ' ｜ ' + (s.hasEnd ? 'E:' + level.end : '无终点') +
      ' ｜ 障碍 ' + s.obstacles + ' ｜ 枢纽 ' + s.hubs +
      ' ｜ 斜向 ' + s.diagonals + ' ｜ 红边 ' + s.redEdges + ' ｜ 绿边 ' + s.greenEdges;
  }

  function setStatus(html) {
    App.setStatus(html);
  }

  function getLevel() { return level; }
  function getTool() { return tool; }

  return {
    init, render, setTool, undo, redo, clearLevel, newLevel,
    exportLevel, play, getLevel, getTool, snapshot, loadSample
  };
})();

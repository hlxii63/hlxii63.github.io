'use strict';
/* =========================================================
 * 路径谜题 · 规则引擎（纯逻辑，无 DOM 依赖）
 *
 * 规则：
 *  - 普通格：恰好经过一次（整条路径为哈密顿路径）
 *  - 起点 S / 终点 E：各恰好一次（S 为首格、E 为末格，不可重复进入）
 *  - 障碍格：完全不可进入
 *  - 枢纽：至少经过一次，可多次经过
 *  - 斜向连线格：允许斜向进入/离开（斜向移动段需至少一端为斜向格）
 *  - 红边：禁止跨越；绿边：必须跨越（至少一次）
 *  - 红/绿边可位于上下左右或斜向相邻格之间
 * ========================================================= */

const KEY = (r, c) => r + ',' + c;

function clampInt(v, min, max, def) {
  v = Number(v);
  if (!Number.isFinite(v)) return def;
  return Math.max(min, Math.min(max, Math.round(v)));
}

class Level {
  constructor(rows, cols, name) {
    this.rows = clampInt(rows, 2, 30, 6);
    this.cols = clampInt(cols, 2, 30, 6);
    this.name = (typeof name === 'string' && name.trim()) ? name.trim().slice(0, 40) : '未命名关卡';
    this.start = null;      // [r, c]
    this.end = null;        // [r, c]
    this.obstacles = new Set();   // "r,c"
    this.hubs = new Set();        // "r,c"
    this.diagonals = new Set();   // "r,c"
    this.redEdges = new Set();    // "r1,c1|r2,c2"（归一化键）
    this.greenEdges = new Set();
  }

  inBounds(r, c) { return r >= 0 && r < this.rows && c >= 0 && c < this.cols; }
  isObstacle(r, c) { return this.obstacles.has(KEY(r, c)); }
  isHub(r, c) { return this.hubs.has(KEY(r, c)); }
  isDiagonal(r, c) { return this.diagonals.has(KEY(r, c)); }
  isStart(r, c) { return !!this.start && this.start[0] === r && this.start[1] === c; }
  isEnd(r, c) { return !!this.end && this.end[0] === r && this.end[1] === c; }

  /* 归一化边键：小的在前 */
  static edgeKey(a, b) {
    const ka = a[0] * 1024 + a[1];
    const kb = b[0] * 1024 + b[1];
    return ka <= kb ? KEY(a[0], a[1]) + '|' + KEY(b[0], b[1])
                    : KEY(b[0], b[1]) + '|' + KEY(a[0], a[1]);
  }

  /* 相邻：上下左右 或 斜向 */
  isAdjacent(a, b) {
    const dr = Math.abs(a[0] - b[0]), dc = Math.abs(a[1] - b[1]);
    return (dr + dc === 1) || (dr === 1 && dc === 1);
  }

  isDiagMove(a, b) {
    const dr = Math.abs(a[0] - b[0]), dc = Math.abs(a[1] - b[1]);
    return dr === 1 && dc === 1;
  }

  /* 移动合法性：斜向移动要求至少一端是斜向格 */
  canMove(a, b) {
    if (!this.isAdjacent(a, b)) return false;
    if (this.isDiagMove(a, b)) {
      return this.isDiagonal(a[0], a[1]) || this.isDiagonal(b[0], b[1]);
    }
    return true;
  }

  hasEdge(color, a, b) {
    const k = Level.edgeKey(a, b);
    return color === 'red' ? this.redEdges.has(k) : this.greenEdges.has(k);
  }

  /* 切换边：存在同色则删除，否则加入（并移除另一色） */
  toggleEdge(color, a, b) {
    const k = Level.edgeKey(a, b);
    if (color === 'red') {
      if (this.redEdges.has(k)) { this.redEdges.delete(k); return false; }
      this.greenEdges.delete(k);
      this.redEdges.add(k);
    } else {
      if (this.greenEdges.has(k)) { this.greenEdges.delete(k); return false; }
      this.redEdges.delete(k);
      this.greenEdges.add(k);
    }
    return true;
  }

  /* 统计（用于编辑器状态栏） */
  stats() {
    return {
      cells: this.rows * this.cols,
      obstacles: this.obstacles.size,
      hubs: this.hubs.size,
      diagonals: this.diagonals.size,
      redEdges: this.redEdges.size,
      greenEdges: this.greenEdges.size,
      hasStart: !!this.start,
      hasEnd: !!this.end
    };
  }

  toJSON() {
    const cellArr = (s) => [...s].map(k => k.split(',').map(Number))
      .sort((x, y) => x[0] - y[0] || x[1] - y[1]);
    const edgeArr = (s) => [...s].map(k => k.split('|').map(p => p.split(',').map(Number)));
    return {
      version: 1,
      name: this.name,
      rows: this.rows,
      cols: this.cols,
      start: this.start ? this.start.slice() : null,
      end: this.end ? this.end.slice() : null,
      obstacles: cellArr(this.obstacles),
      hubs: cellArr(this.hubs),
      diagonals: cellArr(this.diagonals),
      redEdges: edgeArr(this.redEdges),
      greenEdges: edgeArr(this.greenEdges)
    };
  }

  static fromJSON(obj) {
    const errors = [], warnings = [];
    const lv = new Level(2, 2, '');
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) {
      return { level: null, errors: ['无效的关卡数据'], warnings };
    }
    const rows = Number(obj.rows), cols = Number(obj.cols);
    if (!Number.isInteger(rows) || !Number.isInteger(cols) || rows < 2 || rows > 30 || cols < 2 || cols > 30) {
      errors.push('rows/cols 必须是 2~30 的整数');
    } else {
      lv.rows = rows; lv.cols = cols;
    }
    lv.name = (typeof obj.name === 'string' && obj.name.trim()) ? obj.name.trim().slice(0, 40) : '未命名关卡';

    const okCell = (p) => Array.isArray(p) && p.length === 2 &&
      Number.isInteger(p[0]) && Number.isInteger(p[1]) && lv.inBounds(p[0], p[1]);

    if (obj.start != null) {
      if (okCell(obj.start)) lv.start = [obj.start[0], obj.start[1]];
      else errors.push('起点坐标无效');
    }
    if (obj.end != null) {
      if (okCell(obj.end)) lv.end = [obj.end[0], obj.end[1]];
      else errors.push('终点坐标无效');
    }
    if (lv.start && lv.end && lv.start[0] === lv.end[0] && lv.start[1] === lv.end[1]) {
      errors.push('起点与终点不能是同一格');
    }

    const sets = { obstacles: lv.obstacles, hubs: lv.hubs, diagonals: lv.diagonals };
    for (const name of ['obstacles', 'hubs', 'diagonals']) {
      const arr = obj[name];
      if (arr == null) continue;
      if (!Array.isArray(arr)) { errors.push(name + ' 必须是数组'); continue; }
      for (const p of arr) {
        if (!okCell(p)) { errors.push(name + ' 含有无效坐标 [' + JSON.stringify(p) + ']'); continue; }
        sets[name].add(KEY(p[0], p[1]));
      }
    }
    /* 障碍不能与枢纽/斜向/起终点重叠 */
    for (const k of lv.obstacles) {
      if (lv.hubs.has(k)) errors.push('障碍与枢纽重叠于 (' + k + ')');
      if (lv.diagonals.has(k)) errors.push('障碍与斜向格重叠于 (' + k + ')');
      if (lv.start && KEY(lv.start[0], lv.start[1]) === k) errors.push('障碍与起点重叠于 (' + k + ')');
      if (lv.end && KEY(lv.end[0], lv.end[1]) === k) errors.push('障碍与终点重叠于 (' + k + ')');
    }
    /* 枢纽+斜向 = 斜向枢纽（合法组合） */

    const parseEdges = (arr, set, color) => {
      if (arr == null) return;
      if (!Array.isArray(arr)) { errors.push(color + 'Edges 必须是数组'); return; }
      for (const e of arr) {
        if (!Array.isArray(e) || e.length !== 2 || !okCell(e[0]) || !okCell(e[1])) {
          errors.push(color + '边含有无效坐标 ' + JSON.stringify(e)); continue;
        }
        if (!lv.isAdjacent(e[0], e[1])) {
          errors.push(color + '边两端不相邻: (' + e[0] + ')-(' + e[1] + ')'); continue;
        }
        set.add(Level.edgeKey(e[0], e[1]));
      }
    };
    parseEdges(obj.redEdges, lv.redEdges, 'red');
    parseEdges(obj.greenEdges, lv.greenEdges, 'green');
    for (const k of lv.redEdges) {
      if (lv.greenEdges.has(k)) errors.push('同一条边同时标为红与绿: ' + k);
    }
    /* 与障碍相连的边无意义 → 警告 */
    const touchOb = (s) => {
      for (const k of s) {
        const [a, b] = k.split('|').map(p => p.split(',').map(Number));
        if (lv.isObstacle(a[0], a[1]) || lv.isObstacle(b[0], b[1])) {
          warnings.push('存在与障碍相连的边: ' + k);
        }
      }
    };
    touchOb(lv.redEdges); touchOb(lv.greenEdges);
    if (!lv.start || !lv.end) warnings.push('关卡缺少起点或终点（编辑器中可继续补全）');
    return { level: lv, errors, warnings };
  }
}

/* =========================================================
 * 路径校验：分析当前绘制的路径
 * 返回：{ valid, complete, errors, missingCells, missingHubs,
 *         missingGreens, totalNormal, visitedNormal, ... }
 * ========================================================= */
function analyzePath(level, path) {
  const res = {
    valid: true,
    complete: false,
    errors: [],
    totalNormal: 0, visitedNormal: 0,
    totalHubs: level.hubs.size, visitedHubs: 0,
    totalGreen: level.greenEdges.size, crossedGreen: 0,
    missingCells: [], missingHubs: [], missingGreens: [],
    redCells: [], dupCells: [],
    lastCell: null
  };
  const normalKeys = new Set();
  for (let r = 0; r < level.rows; r++) {
    for (let c = 0; c < level.cols; c++) {
      if (level.isObstacle(r, c) || level.isHub(r, c) || level.isStart(r, c) || level.isEnd(r, c)) continue;
      normalKeys.add(KEY(r, c));
    }
  }
  res.totalNormal = normalKeys.size;

  if (!path || path.length === 0) {
    res.valid = false;
    res.errors.push('尚未开始画路径（请从起点 S 开始）');
    return res;
  }

  const count = new Map();
  for (const p of path) {
    const k = KEY(p[0], p[1]);
    count.set(k, (count.get(k) || 0) + 1);
  }
  const crossed = new Set();

  const first = path[0];
  if (!level.isStart(first[0], first[1])) res.errors.push('路径必须从起点 S 开始');
  const last = path[path.length - 1];
  res.lastCell = last;

  for (let i = 1; i < path.length; i++) {
    const a = path[i - 1], b = path[i];
    const ka = KEY(a[0], a[1]), kb = KEY(b[0], b[1]);
    if (!level.isAdjacent(a, b)) {
      res.errors.push('非法移动: (' + ka + ') → (' + kb + ')');
    } else {
      if (level.isDiagMove(a, b) &&
          !(level.isDiagonal(a[0], a[1]) || level.isDiagonal(b[0], b[1]))) {
        res.errors.push('斜向移动需要斜向连线格: (' + ka + ') → (' + kb + ')');
      }
      if (level.hasEdge('red', a, b)) {
        res.errors.push('跨越红边: (' + ka + ')-(' + kb + ')');
        res.redCells.push(ka, kb);
      }
      if (level.hasEdge('green', a, b)) crossed.add(Level.edgeKey(a, b));
    }
    if (level.isObstacle(b[0], b[1])) res.errors.push('进入障碍格: (' + kb + ')');
    if (level.isStart(b[0], b[1])) res.errors.push('不能重复进入起点: (' + kb + ')');
    if (level.isEnd(b[0], b[1]) && i < path.length - 1) res.errors.push('终点之后不能再移动');
  }

  /* 访问次数检查 */
  for (const p of path) {
    const k = KEY(p[0], p[1]);
    const n = count.get(k) || 0;
    if (level.isStart(p[0], p[1]) || level.isEnd(p[0], p[1])) {
      if (n > 1) res.errors.push('起点/终点被重复经过: (' + k + ')');
    } else if (level.isHub(p[0], p[1])) {
      /* 枢纽可多次经过 */
    } else if (level.isObstacle(p[0], p[1])) {
      /* 已在步骤中提示 */
    } else {
      if (n > 1) { res.errors.push('普通格被重复经过: (' + k + ')'); res.dupCells.push(k); }
    }
  }

  /* 覆盖检查 */
  for (const k of normalKeys) {
    if (!count.has(k)) res.missingCells.push(k);
  }
  for (const k of level.hubs) {
    if (!count.has(k)) res.missingHubs.push(k);
  }
  for (const k of level.greenEdges) {
    if (!crossed.has(k)) res.missingGreens.push(k);
  }
  res.visitedNormal = normalKeys.size - res.missingCells.length;
  res.visitedHubs = level.hubs.size - res.missingHubs.length;
  res.crossedGreen = crossed.size;

  if (!level.isEnd(last[0], last[1])) {
    res.valid = false;
    res.errors.push('路径尚未到达终点 E');
  }
  res.valid = res.errors.length === 0;
  res.complete = res.valid &&
    res.missingCells.length === 0 &&
    res.missingHubs.length === 0 &&
    res.missingGreens.length === 0;
  return res;
}

/* =========================================================
 * 内置示例关卡（均已用求解器验证可解）
 * ========================================================= */
const SAMPLE_LEVELS = [
  {
    id: 'sample1',
    name: '新手教学 · 4×4 蛇形',
    rows: 4, cols: 4, start: [0, 0], end: [3, 0],
    obstacles: [], hubs: [], diagonals: [],
    redEdges: [], greenEdges: []
  },
  {
    id: 'sample2',
    name: '障碍与枢纽 · 5×5',
    rows: 5, cols: 5, start: [0, 0], end: [4, 0],
    obstacles: [[1, 1], [3, 3]], hubs: [[2, 2]], diagonals: [[1, 2], [2, 1]],
    redEdges: [], greenEdges: []
  },
  {
    id: 'sample3',
    name: '红绿边 · 4×4',
    rows: 4, cols: 4, start: [0, 0], end: [0, 3],
    obstacles: [], hubs: [], diagonals: [],
    redEdges: [[[1, 1], [1, 2]]],
    greenEdges: [[[0, 1], [0, 2]], [[1, 2], [2, 2]]]
  },
  {
    id: 'sample4',
    name: '斜向枢纽 · 5×5',
    rows: 5, cols: 5, start: [0, 0], end: [4, 0],
    obstacles: [], hubs: [[1, 1]],
    diagonals: [[1, 1], [1, 3], [3, 1], [3, 3]],
    redEdges: [], greenEdges: []
  },
  {
    id: 'sample5',
    name: '综合挑战 · 6×6',
    rows: 6, cols: 6, start: [0, 0], end: [5, 5],
    obstacles: [[1, 2], [4, 3]], hubs: [[2, 2]], diagonals: [[1, 1], [4, 4]],
    redEdges: [[[2, 3], [3, 3]]],
    greenEdges: [[[0, 4], [0, 5]], [[2, 2], [2, 3]]]
  }
];

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { Level, analyzePath, SAMPLE_LEVELS, KEY, clampInt };
}

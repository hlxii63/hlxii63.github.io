'use strict';
/* =========================================================
 * 路径谜题 · 游玩（试玩）模块
 * 玩法：从起点 S 出发画一条路径，经过每个普通格恰好一次，
 *       至少经过每个枢纽一次、覆盖所有绿边、不跨越红边，
 *       最后到达终点 E。
 * ========================================================= */

const Player = (function () {
  let canvas = null;
  let level = null;
  let path = [];
  let analysis = null;
  let won = false;
  let drawing = false;
  let showNumbers = false;
  let startTime = 0;

  function $(id) { return document.getElementById(id); }

  function init() {
    canvas = $('game');
    canvas.addEventListener('pointerdown', onDown);
    canvas.addEventListener('pointermove', onMove);
    canvas.addEventListener('pointerup', onUp);
    canvas.addEventListener('pointercancel', onUp);

    $('p-undo').addEventListener('click', undoStep);
    $('p-clear').addEventListener('click', clearPath);
    $('p-numbers').addEventListener('change', e => { showNumbers = e.target.checked; render(); });
    $('p-back').addEventListener('click', () => App.switchMode('editor'));

    $('win-restart').addEventListener('click', () => {
      hideWin();
      clearPath();
    });
    $('win-back').addEventListener('click', () => App.switchMode('editor'));
  }

  /* 载入关卡（JSON 对象） */
  function loadLevel(jsonObj) {
    const r = Level.fromJSON(jsonObj);
    if (!r.level) return;
    level = r.level;
    reset();
    $('p-levelname').textContent = '关卡：' + level.name;
  }

  function reset() {
    path = [];
    won = false;
    startTime = Date.now();
    analysis = analyzePath(level, path);
    hideWin();
    render();
    updateStatus();
  }

  /* ---------- 事件 ---------- */
  function onDown(e) {
    if (App.getMode() !== 'player' || !level) return;
    e.preventDefault();
    if (won) return;
    const cell = Render.cellAt(canvas, level, e.clientX, e.clientY);
    if (!cell) return;
    drawing = true;
    try {
      canvas.setPointerCapture(e.pointerId);
    } catch (err) { /* 忽略 */ }
    tryAppend(cell, false);
  }

  function onMove(e) {
    if (!drawing || App.getMode() !== 'player' || !level) return;
    const cell = Render.cellAt(canvas, level, e.clientX, e.clientY);
    if (!cell) return;
    const last = path[path.length - 1];
    if (!last || (last[0] === cell[0] && last[1] === cell[1])) return;
    interpolate(cell);
  }

  function onUp() {
    drawing = false;
  }

  function interpolate(to) {
    let guard = 0;
    while (guard++ < 64) {
      const last = path[path.length - 1];
      if (last[0] === to[0] && last[1] === to[1]) break;
      const dr = Math.sign(to[0] - last[0]);
      const dc = Math.sign(to[1] - last[1]);
      const next = [last[0] + dr, last[1] + dc];
      if (!tryAppend(next, true)) break;
    }
    render();
  }

  /* ---------- 画线核心 ---------- */
  function tryAppend(cell, silent) {
    const [r, c] = cell;
    if (!level.inBounds(r, c)) return false;

    if (path.length === 0) {
      if (!level.isStart(r, c)) {
        if (!silent) App.toast('请从起点 S 开始画线');
        return false;
      }
      path.push([r, c]);
      analysis = analyzePath(level, path);
      updateStatus();
      return true;
    }

    const last = path[path.length - 1];
    if (last[0] === r && last[1] === c) return false;

    /* 终点：只有路径完整时才允许进入 */
    if (level.isEnd(r, c)) {
      const hypo = path.slice();
      hypo.push([r, c]);
      const an = analyzePath(level, hypo);
      if (an.complete) {
        path = hypo;
        finish(an);
        return true;
      }
      if (!silent) {
        App.toast('还不能到达终点：还需 ' + an.missingCells.length + ' 个普通格、' +
          an.missingHubs.length + ' 个枢纽、' + an.missingGreens.length + ' 条绿边');
      }
      return false;
    }

    if (!level.canMove(last, cell)) {
      if (!silent) App.toast('无法移动到这里（斜向需斜向格）');
      return false;
    }
    if (level.hasEdge('red', last, cell)) {
      if (!silent) App.toast('❌ 红边禁止通过');
      return false;
    }
    if (level.isObstacle(r, c)) {
      if (!silent) App.toast('这里是障碍格');
      return false;
    }
    if (level.isStart(r, c)) {
      if (!silent) App.toast('不能重复进入起点');
      return false;
    }
    if (!level.isHub(r, c)) {
      for (const p of path) {
        if (p[0] === r && p[1] === c) {
          if (!silent) App.toast('普通格不能重复经过');
          return false;
        }
      }
    }
    path.push([r, c]);
    analysis = analyzePath(level, path);
    updateStatus();
    return true;
  }

  function finish(an) {
    won = true;
    analysis = an;
    render();
    const secs = ((Date.now() - startTime) / 1000).toFixed(1);
    $('win-stats').textContent =
      '用时 ' + secs + ' 秒 · 步数 ' + (path.length - 1) + ' · 覆盖 ' +
      an.totalNormal + ' 个普通格 + ' + level.hubs.size + ' 个枢纽';
    showWin();
    App.setStatus('🎉 通关成功！');
  }

  /* ---------- 操作 ---------- */
  function undoStep() {
    if (path.length === 0) { App.toast('还没有可撤销的步骤'); return; }
    path.pop();
    won = false;
    analysis = analyzePath(level, path);
    render();
    updateStatus();
  }

  function clearPath() {
    path = [];
    won = false;
    startTime = Date.now();
    analysis = analyzePath(level, path);
    render();
    updateStatus();
    hideWin();
  }

  /* ---------- 渲染 ---------- */
  function render() {
    if (!canvas || !level) return;
    const h = {};
    if (analysis && (analysis.redCells.length || analysis.dupCells.length)) {
      h.errors = analysis.redCells.concat(analysis.dupCells);
    }
    Render.draw(canvas, level, {
      path,
      showNumbers,
      highlights: h
    });
  }

  function updateStatus() {
    if (!analysis) return;
    const an = analysis;
    let msg = '普通格 ' + an.visitedNormal + '/' + an.totalNormal +
      ' · 枢纽 ' + an.visitedHubs + '/' + an.totalHubs +
      ' · 绿边 ' + an.crossedGreen + '/' + an.totalGreen +
      ' · 步数 ' + Math.max(0, path.length - 1);
    if (won) msg = '🎉 通关成功！' + msg;
    else if (an.errors.length) msg += ' ｜ ⚠ ' + an.errors[0];
    else msg += ' ｜ 继续画线，目标：' + an.missingCells.length + ' 个普通格 / ' +
      an.missingHubs.length + ' 个枢纽 / ' + an.missingGreens.length + ' 条绿边未覆盖';
    App.setStatus(msg);
  }

  /* ---------- 通关浮层 ---------- */
  function showWin() {
    $('win-overlay').classList.add('show');
  }
  function hideWin() {
    $('win-overlay').classList.remove('show');
  }

  return {
    init, loadLevel, undoStep, clearPath, reset, render
  };
})();

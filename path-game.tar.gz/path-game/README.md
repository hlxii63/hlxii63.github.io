# 🧩 路径谜题 · 关卡编辑器与游玩

一个基于 HTML5 Canvas 的路径规划谜题游戏：在 m×n 方格中从起点 S 画一条路径到终点 E，
使得**每个普通格恰好经过一次**（哈密顿路径），并满足各种特殊元素约束。

## 📜 规则

| 元素 | 规则 |
|---|---|
| 普通格 | 恰好经过一次 |
| 起点 S / 终点 E | 各恰好一次（S 为首格、E 为末格，不可重复进入） |
| 障碍格 ⬛ | 完全不可进入 |
| 枢纽 ◎ | 至少经过一次，可多次经过 |
| 斜向连线格 ╳ | 允许斜向进入/离开（斜向移动段需至少一端为斜向格） |
| 斜向枢纽 ◎╳ | 枢纽 + 斜向格（可多次经过且可斜向进出） |
| 红边 | 路径禁止跨越 |
| 绿边 | 路径必须跨越（至少一次） |

红/绿边可位于**上下左右或斜向相邻**的格子之间。
通关条件：到达 E，且普通格恰好一次、枢纽 ≥1 次、所有绿边均被跨越。

## 🚀 快速开始（浏览器直接玩）

**方式一（最简单，推荐）**：打开单文件版

```
www/index-standalone.html
```

所有代码已内嵌进这一个文件，双击即可运行，不需要任何其他文件。

**方式二**：打开完整版

```
www/index.html
```

> 注意：`index.html` 依赖同目录下的 `css/` 与 `js/` 文件夹，请保持完整目录结构，不要单独移动它。

**方式三**：本地服务器（部分浏览器/手机对本地文件限制较多时）

```bash
npx serve www -l 8080     # 需要已安装 node
# 或
python3 -m http.server 8080 -d www
```

然后访问 `http://localhost:8080`

> 提示：游戏为纯本地运行、无网络依赖。若打开后一片空白，按 F12 查看 Console 报错信息，通常是文件路径/目录结构问题，换用方式一即可。

## 📦 打包为安卓 App（Capacitor）

需要环境：Node.js ≥ 18、Android Studio（含 Android SDK）。

```bash
# 1. 安装依赖（首次）
npm install

# 2. 生成安卓工程
npx cap add android

# 3. 同步网页资源到安卓工程
npx cap sync android

# 4. 用 Android Studio 打开并构建 APK
npx cap open android
# 在 Android Studio 中：Build → Build App Bundle(s) / APK(s) → Build APK(s)
```

构建产物在 `android/app/build/outputs/apk/debug/app-debug.apk`。
安装到手机：`adb install android/app/build/outputs/apk/debug/app-debug.apk`

> 修改 `capacitor.config.json` 中的 `appId`（如 `com.你的域名.路径谜题`）后再打包上架。
> 更换应用图标：替换 `android/app/src/main/res/mipmap-*` 下的图标文件。

## 🛠️ 编辑器功能

- **工具**：起点 S / 终点 E / 障碍 / 枢纽 / 斜向格 / 擦除 / 红边 / 绿边
- **红/绿边**：先点一格，再点相邻格（上下左右或斜向）；再点一次同色对可删除
- **撤销/重做**：按钮或快捷键 Ctrl+Z / Ctrl+Y（Shift+Ctrl+Z 重做）
- **尺寸**：2~30 行/列，可随时新建
- **示例关卡**：内置 5 个关卡（均已验证可解）
- **导出/导入**：JSON 文件或文本（下载 / 复制 / 粘贴导入）
- **试玩**：一键进入游玩模式

## 🎮 游玩功能

- 从 S 开始点击或**拖动画线**，实时校验
- 撤销一步 / 清空路径 / 显示序号（辅助思考）
- 实时状态：普通格、枢纽、绿边覆盖进度与错误提示
- 通关统计：用时 / 步数

## 📁 项目结构

```
path-game/
├── www/                     # 网页资源（Capacitor webDir）
│   ├── index.html           # 主页面
│   ├── css/style.css        # 样式
│   ├── js/
│   │   ├── level.js         # 规则引擎（纯逻辑）：Level 模型 / 校验 / 示例
│   │   ├── render.js        # Canvas 渲染
│   │   ├── editor.js        # 编辑器逻辑
│   │   ├── player.js        # 游玩逻辑
│   │   └── app.js           # 引导与切换
│   └── levels/              # 示例关卡 JSON
├── capacitor.config.json    # Capacitor 配置
├── package.json             # npm 依赖与脚本
└── README.md
```

## 📄 关卡 JSON 格式

```json
{
  "version": 1,
  "name": "关卡名",
  "rows": 6, "cols": 6,
  "start": [0, 0], "end": [5, 5],
  "obstacles": [[1, 1], [4, 4]],
  "hubs": [[2, 2]],
  "diagonals": [[1, 1]],
  "redEdges": [[[2, 3], [3, 3]]],
  "greenEdges": [[[0, 4], [0, 5]]]
}
```

坐标均为 `[行, 列]`（0 起始）；边为一对相邻格（上下左右或斜向）。
导入时会校验：坐标越界、障碍与枢纽重叠、边不相邻、红绿同边等。
